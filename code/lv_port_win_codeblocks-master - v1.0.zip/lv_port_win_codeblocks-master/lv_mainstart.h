#ifndef __LV_MAINSTART_H
#define __LV_MAINSTART_H

extern void my_gui(void);

#endif // _MY_GUI_H_
