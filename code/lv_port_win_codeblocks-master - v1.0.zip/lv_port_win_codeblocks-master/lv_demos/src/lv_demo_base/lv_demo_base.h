#ifndef _LV_DEMO_BASE_H

#define _LV_DEMO_BASE_H

#include "lvgl/lvgl.h"

void lv_demo_base(void);

#endif
