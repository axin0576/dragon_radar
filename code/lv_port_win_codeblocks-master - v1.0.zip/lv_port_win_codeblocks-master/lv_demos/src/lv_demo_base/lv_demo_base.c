#include "lv_demo_base.h"

void lv_demo_base(void)
{
    lv_obj_t * obj1 = lv_obj_create(lv_scr_act());
    lv_obj_align(obj1, LV_ALIGN_TOP_LEFT, 0, 0);
}
