
LED with custom style
"""""""""""""""""""""

.. lv_example:: widgets/led/lv_example_led_1
  :language: c

