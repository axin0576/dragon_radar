#ifndef __MY_GUI_H
#define __MY_GUI_H

extern void my_gui(void);

#endif // _MY_GUI_H_
