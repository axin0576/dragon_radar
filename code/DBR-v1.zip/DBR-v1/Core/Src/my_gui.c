#include "my_gui.h"
#include "lvgl.h"
#include <stdio.h>
//#include "lv_drivers/win32drv/win32drv.h"
#include "math.h"
#include "lv_port_indev_template.h"

#define LEN 50
#define LEN_JIAN_TOU 155

static const lv_font_t* font;       /* �������� */

#define scr_act_width() lv_obj_get_width(lv_scr_act())
#define scr_act_height() lv_obj_get_height(lv_scr_act())


static lv_obj_t* lv_main_menu_obj;
lv_obj_t* lv_main_menu_btn1_obj;
lv_obj_t* lv_main_menu_btn2_obj;
lv_obj_t* lv_main_menu_btn3_obj;
static lv_group_t* g;


static lv_obj_t *lv_menu_one_obj;
lv_obj_t *lv_menu_one_btn1_obj;
lv_obj_t *bg_img, *ball_1_img,*ball_2_img,*ball_3_img,*ball_4_img,*ball_5_img,*ball_6_img,*ball_7_img;
lv_obj_t *ball_jiantou1_img,*ball_jiantou2_img,*ball_jiantou3_img,*ball_jiantou4_img,*ball_jiantou5_img,*ball_jiantou6_img,*ball_jiantou7_img;
lv_obj_t *zhishi_img;
lv_obj_t *long_img;



static lv_style_t ball_img_style;
static lv_style_t jiantou_img_style;


static void btn_event_cb(lv_event_t * e)
{
    lv_obj_t *target = lv_event_get_target(e);      /* ��ȡ����Դ */
    printf("btn_event_cb\n");
    static int bg_img_cnt = 0;
    if(target == lv_main_menu_btn1_obj)
    {
                    // ����ҳ��2����ʾҳ��1
                    lv_obj_add_flag(lv_main_menu_obj, LV_OBJ_FLAG_HIDDEN);
                    lv_obj_clear_flag(lv_menu_one_obj, LV_OBJ_FLAG_HIDDEN);
                    // �л���ҳ��1ʱ�������������Ķ�������Ϊҳ��1�İ�ť
                    lv_group_remove_all_objs(g);
                    lv_group_add_obj(g, bg_img);
                    lv_group_focus_obj(bg_img);
                    printf("menu1\n");

    }
    else if(target == lv_main_menu_btn2_obj)
    {
//        lv_scr_load_anim(lv_main_menu_obj, LV_SCR_LOAD_ANIM_NONE, 0, 0, false);
        printf("menu2\n");
    }
    else if(target == lv_main_menu_btn3_obj)
    {
//        lv_scr_load_anim(lv_main_menu_obj, LV_SCR_LOAD_ANIM_NONE, 0, 0, false);
        printf("menu3\n");
    }
    else if(target == bg_img)
    {
        bg_img_cnt++;

        printf("cnt = %d \n", bg_img_cnt);

        if (bg_img_cnt == 9)
        {
            lv_obj_add_flag(long_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(ball_jiantou1_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(ball_jiantou2_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(ball_jiantou3_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(ball_jiantou4_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(ball_jiantou5_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(ball_jiantou6_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(ball_jiantou7_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_clear_flag(zhishi_img, LV_OBJ_FLAG_HIDDEN);


                    // ����
                    lv_obj_add_flag(lv_menu_one_obj, LV_OBJ_FLAG_HIDDEN);
                    lv_obj_clear_flag(lv_main_menu_obj, LV_OBJ_FLAG_HIDDEN);

                    // �л���ҳ��1ʱ�������������Ķ�������Ϊҳ��1�İ�ť
                    lv_group_remove_all_objs(g);
                    lv_group_add_obj(g, lv_main_menu_btn1_obj);
                    lv_group_add_obj(g, lv_main_menu_btn2_obj);
                    lv_group_add_obj(g, lv_main_menu_btn3_obj);
                    lv_group_focus_obj(lv_main_menu_btn1_obj);
                    printf("menu4\n");



            bg_img_cnt = 0;
        }
        else if (bg_img_cnt == 1)
        {
            lv_obj_clear_flag(ball_1_img, LV_OBJ_FLAG_HIDDEN);

            lv_img_set_angle(zhishi_img, 514*bg_img_cnt);

            lv_obj_add_flag(ball_jiantou1_img, LV_OBJ_FLAG_HIDDEN);
        }
        else if (bg_img_cnt == 2)
        {
            lv_obj_clear_flag(ball_2_img, LV_OBJ_FLAG_HIDDEN);

            lv_img_set_angle(zhishi_img, 514*bg_img_cnt);

            lv_obj_add_flag(ball_jiantou2_img, LV_OBJ_FLAG_HIDDEN);
        }
        else if (bg_img_cnt == 3)
        {
            lv_obj_clear_flag(ball_3_img, LV_OBJ_FLAG_HIDDEN);

            lv_img_set_angle(zhishi_img, 514*bg_img_cnt);

            lv_obj_add_flag(ball_jiantou3_img, LV_OBJ_FLAG_HIDDEN);
        }
        else if (bg_img_cnt == 4)
        {
            lv_obj_clear_flag(ball_4_img, LV_OBJ_FLAG_HIDDEN);

            lv_img_set_angle(zhishi_img, 514*bg_img_cnt);

            lv_obj_add_flag(ball_jiantou4_img, LV_OBJ_FLAG_HIDDEN);
        }
        else if (bg_img_cnt == 5)
        {
            lv_obj_clear_flag(ball_5_img, LV_OBJ_FLAG_HIDDEN);

            lv_img_set_angle(zhishi_img, 514*bg_img_cnt);

            lv_obj_add_flag(ball_jiantou5_img, LV_OBJ_FLAG_HIDDEN);
        }
        else if (bg_img_cnt == 6)
        {
            lv_obj_clear_flag(ball_6_img, LV_OBJ_FLAG_HIDDEN);

            lv_img_set_angle(zhishi_img, 514*bg_img_cnt);

            lv_obj_add_flag(ball_jiantou6_img, LV_OBJ_FLAG_HIDDEN);
        }
        else if (bg_img_cnt == 7)
        {
            ball_7_img = lv_img_create(lv_menu_one_obj);
            LV_IMG_DECLARE(ball_7);				/* ����ͼƬ */
            lv_img_set_src(ball_7_img, &ball_7);			/* ����ͼƬԴ */
            lv_obj_add_style(ball_7_img, &ball_img_style, 0); //������ʽ
            lv_obj_align(ball_7_img,LV_ALIGN_CENTER, LEN*sin(-0.897*(bg_img_cnt-1)+3.14),LEN*cos(-0.897*(bg_img_cnt-1)+3.14)); //0.897  155

            lv_img_set_angle(zhishi_img, 514*bg_img_cnt);

            lv_obj_add_flag(ball_jiantou7_img, LV_OBJ_FLAG_HIDDEN);
        }
        else if (bg_img_cnt == 8)
        {
            lv_obj_add_flag(ball_jiantou7_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(ball_1_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(ball_2_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(ball_3_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(ball_4_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(ball_5_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(ball_6_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(ball_7_img, LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(zhishi_img, LV_OBJ_FLAG_HIDDEN);


            lv_obj_clear_flag(long_img, LV_OBJ_FLAG_HIDDEN);

        }
    }
}



static lv_style_t style;
static lv_style_t style_font;
static lv_style_t style_label;

static void lv_main_menu_page(void)
{
    // Բ����Ļ���
    lv_style_init(&style);
    lv_style_set_width(&style, scr_act_width());
    lv_style_set_height(&style, scr_act_height());
    lv_style_set_radius(&style, scr_act_width()/2); //Բ��
    lv_style_set_bg_opa(&style, LV_OPA_100); //͸���� 0-100
    lv_style_set_bg_color(&style, lv_palette_lighten(LV_PALETTE_GREY, 4)); // ����ɫ��ɻ�ɫ

    // �˵��б���ť���
    lv_style_init(&style_font);
    lv_style_set_width(&style_font, 220);
    lv_style_set_height(&style_font, 30);
    lv_style_set_bg_opa(&style_font, LV_OPA_0);
    lv_style_set_shadow_width(&style_font, 0);

    // �˵��б��ַ����
    lv_style_init(&style_label);
    lv_style_set_align(&style_label, LV_ALIGN_LEFT_MID);
    lv_style_set_text_font(&style_label, font);
    lv_style_set_text_color(&style_label, lv_color_hex(0x000000));



    /*---------------------------���˵�ҳ��------------------------------------*/
    lv_main_menu_obj = lv_obj_create(lv_scr_act());
    lv_obj_add_style(lv_main_menu_obj, &style, 0); //������ʽ
    lv_obj_center(lv_main_menu_obj); //����


    lv_main_menu_btn1_obj = lv_btn_create(lv_main_menu_obj);
    lv_obj_add_style(lv_main_menu_btn1_obj, &style_font, 0); //������ʽ
    lv_obj_align(lv_main_menu_btn1_obj, LV_ALIGN_TOP_MID, 0, 100);
    lv_obj_add_event_cb(lv_main_menu_btn1_obj, btn_event_cb, LV_EVENT_CLICKED,NULL );
    lv_obj_t* label_1_obj = lv_label_create(lv_main_menu_btn1_obj);
    lv_obj_add_style(label_1_obj, &style_label, 0);
    lv_label_set_text(label_1_obj, "Find Dragon Ball");

    lv_main_menu_btn2_obj = lv_btn_create(lv_main_menu_obj);
    lv_obj_add_style(lv_main_menu_btn2_obj, &style_font, 0); //������ʽ
    lv_obj_align_to(lv_main_menu_btn2_obj, lv_main_menu_btn1_obj, LV_ALIGN_OUT_BOTTOM_MID, 0, 20);
    lv_obj_add_event_cb(lv_main_menu_btn2_obj, btn_event_cb, LV_EVENT_CLICKED,NULL );
    lv_obj_t* label_2_obj = lv_label_create(lv_main_menu_btn2_obj);
    lv_obj_add_style(label_2_obj, &style_label, 0);
    lv_label_set_text(label_2_obj, "Snake Game");

    lv_main_menu_btn3_obj = lv_btn_create(lv_main_menu_obj);
    lv_obj_add_style(lv_main_menu_btn3_obj, &style_font, 0); //������ʽ
    lv_obj_align_to(lv_main_menu_btn3_obj, lv_main_menu_btn2_obj, LV_ALIGN_OUT_BOTTOM_MID, 0, 20);
    lv_obj_add_event_cb(lv_main_menu_btn3_obj, btn_event_cb, LV_EVENT_CLICKED,NULL );
    lv_obj_t* label_3_obj = lv_label_create(lv_main_menu_btn3_obj);
    lv_obj_add_style(label_3_obj, &style_label, 0);
    lv_label_set_text(label_3_obj, "Black Myth");


    lv_group_add_obj(g, lv_main_menu_btn1_obj);
    lv_group_add_obj(g, lv_main_menu_btn2_obj);
    lv_group_add_obj(g, lv_main_menu_btn3_obj);

}


static void lv_menu_one_page(void)
{
    lv_menu_one_obj = lv_obj_create(lv_scr_act());
    lv_obj_add_style(lv_menu_one_obj, &style, 0); //������ʽ
    lv_obj_center(lv_menu_one_obj); //����

    //����
    static lv_style_t bg_img_style;
    lv_style_init(&bg_img_style);
    lv_style_set_bg_opa(&bg_img_style, LV_OPA_0); //͸���� 0-100
    lv_style_set_transform_zoom(&bg_img_style, 256*4);
    bg_img = lv_img_create(lv_menu_one_obj);
    LV_IMG_DECLARE(bg_360);				/* ����ͼƬ */
    lv_img_set_src(bg_img, &bg_360);			/* ����ͼƬԴ */
    lv_obj_add_style(bg_img, &bg_img_style, 0); //������ʽ
    lv_obj_align(bg_img,LV_ALIGN_CENTER, 0, 0);

    //long zhu
    #define BALL_ZOOM 240
    lv_style_init(&ball_img_style);
    lv_style_set_bg_opa(&ball_img_style, LV_OPA_0); //͸���� 0-100
    lv_style_set_transform_zoom(&ball_img_style, BALL_ZOOM);

    #define JIANTOU_ZOOM 200
    lv_style_init(&jiantou_img_style);
    lv_style_set_bg_opa(&jiantou_img_style, LV_OPA_0); //͸���� 0-100
    lv_style_set_transform_zoom(&jiantou_img_style, JIANTOU_ZOOM);


            ball_1_img = lv_img_create(lv_menu_one_obj);
            LV_IMG_DECLARE(ball_1);				/* ����ͼƬ */
            lv_img_set_src(ball_1_img, &ball_1);			/* ����ͼƬԴ */
            lv_obj_add_style(ball_1_img, &ball_img_style, 0); //������ʽ
            lv_obj_align(ball_1_img,LV_ALIGN_CENTER, LEN*sin(-0.897*(1-1)+3.14),LEN*cos(-0.897*(1-1)+3.14)); //0.897  155
            lv_obj_add_flag(ball_1_img, LV_OBJ_FLAG_HIDDEN);

            ball_2_img = lv_img_create(lv_menu_one_obj);
            LV_IMG_DECLARE(ball_2);				/* ����ͼƬ */
            lv_img_set_src(ball_2_img, &ball_2);			/* ����ͼƬԴ */
            lv_obj_add_style(ball_2_img, &ball_img_style, 0); //������ʽ
            lv_obj_align(ball_2_img,LV_ALIGN_CENTER, LEN*sin(-0.897*(2-1)+3.14),LEN*cos(-0.897*(2-1)+3.14)); //0.897  155
            lv_obj_add_flag(ball_2_img, LV_OBJ_FLAG_HIDDEN);

            ball_3_img = lv_img_create(lv_menu_one_obj);
            LV_IMG_DECLARE(ball_3);				/* ����ͼƬ */
            lv_img_set_src(ball_3_img, &ball_3);			/* ����ͼƬԴ */
            lv_obj_add_style(ball_3_img, &ball_img_style, 0); //������ʽ
            lv_obj_align(ball_3_img,LV_ALIGN_CENTER, LEN*sin(-0.897*(3-1)+3.14),LEN*cos(-0.897*(3-1)+3.14)); //0.897  155
            lv_obj_add_flag(ball_3_img, LV_OBJ_FLAG_HIDDEN);

            ball_4_img = lv_img_create(lv_menu_one_obj);
            LV_IMG_DECLARE(ball_4);				/* ����ͼƬ */
            lv_img_set_src(ball_4_img, &ball_4);			/* ����ͼƬԴ */
            lv_obj_add_style(ball_4_img, &ball_img_style, 0); //������ʽ
            lv_obj_align(ball_4_img,LV_ALIGN_CENTER, LEN*sin(-0.897*(4-1)+3.14),LEN*cos(-0.897*(4-1)+3.14)); //0.897  155
            lv_obj_add_flag(ball_4_img, LV_OBJ_FLAG_HIDDEN);

            ball_5_img = lv_img_create(lv_menu_one_obj);
            LV_IMG_DECLARE(ball_5);				/* ����ͼƬ */
            lv_img_set_src(ball_5_img, &ball_5);			/* ����ͼƬԴ */
            lv_obj_add_style(ball_5_img, &ball_img_style, 0); //������ʽ
            lv_obj_align(ball_5_img,LV_ALIGN_CENTER, LEN*sin(-0.897*(5-1)+3.14),LEN*cos(-0.897*(5-1)+3.14)); //0.897  155
            lv_obj_add_flag(ball_5_img, LV_OBJ_FLAG_HIDDEN);

            ball_6_img = lv_img_create(lv_menu_one_obj);
            LV_IMG_DECLARE(ball_6);				/* ����ͼƬ */
            lv_img_set_src(ball_6_img, &ball_6);			/* ����ͼƬԴ */
            lv_obj_add_style(ball_6_img, &ball_img_style, 0); //������ʽ
            lv_obj_align(ball_6_img,LV_ALIGN_CENTER, LEN*sin(-0.897*(6-1)+3.14),LEN*cos(-0.897*(6-1)+3.14)); //0.897  155
            lv_obj_add_flag(ball_6_img, LV_OBJ_FLAG_HIDDEN);

            ball_7_img = lv_img_create(lv_menu_one_obj);
            LV_IMG_DECLARE(ball_7);				/* ����ͼƬ */
            lv_img_set_src(ball_7_img, &ball_7);			/* ����ͼƬԴ */
            lv_obj_add_style(ball_7_img, &ball_img_style, 0); //������ʽ
            lv_obj_align(ball_7_img,LV_ALIGN_CENTER, LEN*sin(-0.897*(7-1)+3.14),LEN*cos(-0.897*(7-1)+3.14)); //0.897  155
            lv_obj_add_flag(ball_7_img, LV_OBJ_FLAG_HIDDEN);




    ball_jiantou1_img = lv_img_create(lv_menu_one_obj);
    LV_IMG_DECLARE(jiantou);				/* ����ͼƬ */
    lv_img_set_src(ball_jiantou1_img, &jiantou);			/* ����ͼƬԴ */
    lv_obj_add_style(ball_jiantou1_img, &jiantou_img_style, 0); //������ʽ
    lv_obj_align(ball_jiantou1_img,LV_ALIGN_CENTER, LEN_JIAN_TOU*sin(-0.897*0+3.14),LEN_JIAN_TOU*cos(-0.897*0+3.14)); //0.897  155
    lv_img_set_pivot(ball_jiantou1_img, 21, 10);		/* �������ĵ� */
    lv_img_set_angle(ball_jiantou1_img, 514*0);

    ball_jiantou2_img = lv_img_create(lv_menu_one_obj);
    LV_IMG_DECLARE(jiantou);				/* ����ͼƬ */
    lv_img_set_src(ball_jiantou2_img, &jiantou);			/* ����ͼƬԴ */
    lv_obj_add_style(ball_jiantou2_img, &jiantou_img_style, 0); //������ʽ
    lv_obj_align(ball_jiantou2_img,LV_ALIGN_CENTER, LEN_JIAN_TOU*sin(-0.897*1+3.14),LEN_JIAN_TOU*cos(-0.897*1+3.14));
    lv_img_set_pivot(ball_jiantou2_img, 21, 10);		/* �������ĵ� */
    lv_img_set_angle(ball_jiantou2_img, 514*1);

    ball_jiantou3_img = lv_img_create(lv_menu_one_obj);
    LV_IMG_DECLARE(jiantou);				/* ����ͼƬ */
    lv_img_set_src(ball_jiantou3_img, &jiantou);			/* ����ͼƬԴ */
    lv_obj_add_style(ball_jiantou3_img, &jiantou_img_style, 0); //������ʽ
    lv_obj_align(ball_jiantou3_img,LV_ALIGN_CENTER, LEN_JIAN_TOU*sin(-0.897*2+3.14),LEN_JIAN_TOU*cos(-0.897*2+3.14));
    lv_img_set_pivot(ball_jiantou3_img, 21, 10);		/* �������ĵ� */
    lv_img_set_angle(ball_jiantou3_img, 514*2);

    ball_jiantou4_img = lv_img_create(lv_menu_one_obj);
    LV_IMG_DECLARE(jiantou);				/* ����ͼƬ */
    lv_img_set_src(ball_jiantou4_img, &jiantou);			/* ����ͼƬԴ */
    lv_obj_add_style(ball_jiantou4_img, &jiantou_img_style, 0); //������ʽ
    lv_obj_align(ball_jiantou4_img,LV_ALIGN_CENTER, LEN_JIAN_TOU*sin(-0.897*3+3.14),LEN_JIAN_TOU*cos(-0.897*3+3.14));
    lv_img_set_pivot(ball_jiantou4_img, 21, 10);		/* �������ĵ� */
    lv_img_set_angle(ball_jiantou4_img, 514*3);

    ball_jiantou5_img = lv_img_create(lv_menu_one_obj);
    LV_IMG_DECLARE(jiantou);				/* ����ͼƬ */
    lv_img_set_src(ball_jiantou5_img, &jiantou);			/* ����ͼƬԴ */
    lv_obj_add_style(ball_jiantou5_img, &jiantou_img_style, 0); //������ʽ
    lv_obj_align(ball_jiantou5_img,LV_ALIGN_CENTER, LEN_JIAN_TOU*sin(-0.897*4+3.14),LEN_JIAN_TOU*cos(-0.897*4+3.14));
    lv_img_set_pivot(ball_jiantou5_img, 21, 10);		/* �������ĵ� */
    lv_img_set_angle(ball_jiantou5_img, 514*4);

    ball_jiantou6_img = lv_img_create(lv_menu_one_obj);
    LV_IMG_DECLARE(jiantou);				/* ����ͼƬ */
    lv_img_set_src(ball_jiantou6_img, &jiantou);			/* ����ͼƬԴ */
    lv_obj_add_style(ball_jiantou6_img, &jiantou_img_style, 0); //������ʽ
    lv_obj_align(ball_jiantou6_img,LV_ALIGN_CENTER, LEN_JIAN_TOU*sin(-0.897*5+3.14),LEN_JIAN_TOU*cos(-0.897*5+3.14));
    lv_img_set_pivot(ball_jiantou6_img, 21, 10);		/* �������ĵ� */
    lv_img_set_angle(ball_jiantou6_img, 514*5);

    ball_jiantou7_img = lv_img_create(lv_menu_one_obj);
    LV_IMG_DECLARE(jiantou);				/* ����ͼƬ */
    lv_img_set_src(ball_jiantou7_img, &jiantou);			/* ����ͼƬԴ */
    lv_obj_add_style(ball_jiantou7_img, &jiantou_img_style, 0); //������ʽ
    lv_obj_align(ball_jiantou7_img,LV_ALIGN_CENTER, LEN_JIAN_TOU*sin(-0.897*6+3.14),LEN_JIAN_TOU*cos(-0.897*6+3.14));
    lv_img_set_pivot(ball_jiantou7_img, 21, 10);		/* �������ĵ� */
    lv_img_set_angle(ball_jiantou7_img, 514*6);


    long_img = lv_img_create(lv_menu_one_obj);
    LV_IMG_DECLARE(llong);				/* ����ͼƬ */
    lv_img_set_src(long_img, &llong);			/* ����ͼƬԴ */
    lv_obj_align(long_img,LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_transform_zoom(long_img, 256*2, 0);
    lv_obj_add_flag(long_img, LV_OBJ_FLAG_HIDDEN);




    zhishi_img = lv_img_create(lv_menu_one_obj);
    LV_IMG_DECLARE(zhishi);				/* ����ͼƬ */
    lv_img_set_src(zhishi_img, &zhishi);			/* ����ͼƬԴ */
    lv_obj_add_style(zhishi_img, &jiantou_img_style, 0); //������ʽ
    lv_obj_align(zhishi_img,LV_ALIGN_CENTER, 0, 0);
    lv_img_set_pivot(zhishi_img, 20, 19);		/* �������ĵ� */
    lv_img_set_angle(zhishi_img, -514*0);


    lv_obj_add_event_cb(bg_img, btn_event_cb, LV_EVENT_CLICKED,NULL ); //LV_EVENT_ALL LV_EVENT_CLICKED
}


void lv_main(void)
{
    font = &lv_font_montserrat_22;

    g = lv_group_create();
//    lv_indev_set_group(lv_win32_keypad_device_object, g);     // ����
//    lv_indev_set_group(lv_win32_encoder_device_object, g);      // ����ϵĹ���(������)
		lv_indev_set_group(indev_encoder, g); 



    lv_main_menu_page();
    lv_menu_one_page();

    lv_obj_add_flag(lv_main_menu_obj, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(lv_menu_one_obj, LV_OBJ_FLAG_HIDDEN);
    lv_obj_clear_flag(lv_main_menu_obj, LV_OBJ_FLAG_HIDDEN);


    //lv_scr_load_anim(lv_main_menu_obj, LV_SCR_LOAD_ANIM_NONE, 0, 0, false); //lv_main_menu_obj lv_menu_one_obj

}
