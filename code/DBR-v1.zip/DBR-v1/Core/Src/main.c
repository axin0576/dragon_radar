/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "fsmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

int fputc(int c, FILE *stream)    //��дfputc����
{
 /*
    huart1�ǹ������ɴ��붨���UART1�ṹ�壬
    ����Ժ�Ҫʹ���������ڴ�ӡ��ֻ��Ҫ������ṹ��ĳ�����UART�ṹ�塣
*/
    HAL_UART_Transmit(&huart1, (unsigned char *)&c, 1, 1000);   
    return 1;
}
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void MX_FREERTOS_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void LCD_Setone(void);
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_FSMC_Init();
  MX_TIM10_Init();
  MX_USART1_UART_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
	
	HAL_GPIO_WritePin(lcd_reset_GPIO_Port, lcd_reset_Pin, GPIO_PIN_RESET);
	HAL_Delay(100);
	HAL_GPIO_WritePin(lcd_reset_GPIO_Port, lcd_reset_Pin, GPIO_PIN_SET);
	HAL_Delay(100);
	
	HAL_GPIO_WritePin(led_GPIO_Port, led_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(lcd_pulse_GPIO_Port, lcd_pulse_Pin, GPIO_PIN_SET);

	lv_init(); 
	lv_port_disp_init(); 
	lv_port_indev_init();

  /* USER CODE END 2 */

  /* Call init function for freertos objects (in freertos.c) */
  MX_FREERTOS_Init();

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 6;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void LCD_Setone(void)
{
	ILI9341_Write_Cmd(0xF0);
	ILI9341_Write_Data(0x08);

	ILI9341_Write_Cmd(0xF2);
	ILI9341_Write_Data(0x08);
	ILI9341_Write_Cmd(0x9B);
	ILI9341_Write_Data(0x51);
	ILI9341_Write_Cmd(0x86);
	ILI9341_Write_Data(0x53);
	ILI9341_Write_Cmd(0xF2);
	ILI9341_Write_Data(0x80);
	ILI9341_Write_Cmd(0xF0);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xF0);
	ILI9341_Write_Data(0x01);
	ILI9341_Write_Cmd(0xF1);
	ILI9341_Write_Data(0x01);
	ILI9341_Write_Cmd(0xB0);
	ILI9341_Write_Data(0x54);
	ILI9341_Write_Cmd(0xB1);
	ILI9341_Write_Data(0x3F);
	ILI9341_Write_Cmd(0xB2);
	ILI9341_Write_Data(0x2A);
	ILI9341_Write_Cmd(0xB4);
	ILI9341_Write_Data(0x46);
	ILI9341_Write_Cmd(0xB5);
	ILI9341_Write_Data(0x34);
	ILI9341_Write_Cmd(0xB6);
	ILI9341_Write_Data(0xD5);
	ILI9341_Write_Cmd(0xB7);
	ILI9341_Write_Data(0x30);
	ILI9341_Write_Cmd(0xBA);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xBB);
	ILI9341_Write_Data(0x08);
	ILI9341_Write_Cmd(0xBC);
	ILI9341_Write_Data(0x08);
	ILI9341_Write_Cmd(0xBD);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xC0);
	ILI9341_Write_Data(0x80);
	ILI9341_Write_Cmd(0xC1);
	ILI9341_Write_Data(0x10);
	ILI9341_Write_Cmd(0xC2);

	ILI9341_Write_Data(0x37);
	ILI9341_Write_Cmd(0xC3);
	ILI9341_Write_Data(0x80);
	ILI9341_Write_Cmd(0xC4);
	ILI9341_Write_Data(0x10);
	ILI9341_Write_Cmd(0xC5);
	ILI9341_Write_Data(0x37);
	ILI9341_Write_Cmd(0xC6);
	ILI9341_Write_Data(0xA9);
	ILI9341_Write_Cmd(0xC7);
	ILI9341_Write_Data(0x41);
	ILI9341_Write_Cmd(0xC8);
	ILI9341_Write_Data(0x51);
	ILI9341_Write_Cmd(0xC9);
	ILI9341_Write_Data(0xA9);
	ILI9341_Write_Cmd(0xCA);
	ILI9341_Write_Data(0x41);
	ILI9341_Write_Cmd(0xCB);
	ILI9341_Write_Data(0x51);
	ILI9341_Write_Cmd(0xD0);
	ILI9341_Write_Data(0x91);
	ILI9341_Write_Cmd(0xD1);
	ILI9341_Write_Data(0x68);
	ILI9341_Write_Cmd(0xD2);
	ILI9341_Write_Data(0x69);
	ILI9341_Write_Cmd(0xF5);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Data(0xA5);
	ILI9341_Write_Cmd(0xDD);
	ILI9341_Write_Data(0x3F);
	ILI9341_Write_Cmd(0xDE);
	ILI9341_Write_Data(0x3F);
	ILI9341_Write_Cmd(0xF1);
	ILI9341_Write_Data(0x10);
	ILI9341_Write_Cmd(0xF0);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xF0);
	ILI9341_Write_Data(0x02);
	ILI9341_Write_Cmd(0xE0);
	ILI9341_Write_Data(0xF0);
	ILI9341_Write_Data(0x06);

	ILI9341_Write_Data(0x0B);
	ILI9341_Write_Data(0x09);
	ILI9341_Write_Data(0x09);
	ILI9341_Write_Data(0x16);
	ILI9341_Write_Data(0x32);
	ILI9341_Write_Data(0x44);
	ILI9341_Write_Data(0x4A);
	ILI9341_Write_Data(0x37);
	ILI9341_Write_Data(0x13);
	ILI9341_Write_Data(0x13);
	ILI9341_Write_Data(0x2E);
	ILI9341_Write_Data(0x34);
	ILI9341_Write_Cmd(0xE1);
	ILI9341_Write_Data(0xF0);
	ILI9341_Write_Data(0x06);
	ILI9341_Write_Data(0x0B);
	ILI9341_Write_Data(0x09);
	ILI9341_Write_Data(0x08);
	ILI9341_Write_Data(0x05);
	ILI9341_Write_Data(0x32);
	ILI9341_Write_Data(0x33);
	ILI9341_Write_Data(0x49);
	ILI9341_Write_Data(0x17);
	ILI9341_Write_Data(0x13);
	ILI9341_Write_Data(0x13);
	ILI9341_Write_Data(0x2E);
	ILI9341_Write_Data(0x34);
	ILI9341_Write_Cmd(0xF0);
	ILI9341_Write_Data(0x10);
	ILI9341_Write_Cmd(0xF3);
	ILI9341_Write_Data(0x10);
	ILI9341_Write_Cmd(0xE0);
	ILI9341_Write_Data(0x0A);
	ILI9341_Write_Cmd(0xE1);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xE2);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xE3);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xE4);
	ILI9341_Write_Data(0xE0);

	ILI9341_Write_Cmd(0xE5);
	ILI9341_Write_Data(0x06);
	ILI9341_Write_Cmd(0xE6);
	ILI9341_Write_Data(0x21);
	ILI9341_Write_Cmd(0xE7);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xE8);
	ILI9341_Write_Data(0x05);
	ILI9341_Write_Cmd(0xE9);
	ILI9341_Write_Data(0x82);
	ILI9341_Write_Cmd(0xEA);
	ILI9341_Write_Data(0xDF);
	ILI9341_Write_Cmd(0xEB);
	ILI9341_Write_Data(0x89);
	ILI9341_Write_Cmd(0xEC);
	ILI9341_Write_Data(0x20);
	ILI9341_Write_Cmd(0xED);
	ILI9341_Write_Data(0x14);
	ILI9341_Write_Cmd(0xEE);
	ILI9341_Write_Data(0xFF);
	ILI9341_Write_Cmd(0xEF);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xF8);
	ILI9341_Write_Data(0xFF);
	ILI9341_Write_Cmd(0xF9);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xFA);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xFB);
	ILI9341_Write_Data(0x30);
	ILI9341_Write_Cmd(0xFC);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xFD);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xFE);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xFF);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x60);
	ILI9341_Write_Data(0x42);
	ILI9341_Write_Cmd(0x61);

	ILI9341_Write_Data(0xE0);
	ILI9341_Write_Cmd(0x62);
	ILI9341_Write_Data(0x40);
	ILI9341_Write_Cmd(0x63);
	ILI9341_Write_Data(0x40);
	ILI9341_Write_Cmd(0x64);
	ILI9341_Write_Data(0x02);
	ILI9341_Write_Cmd(0x65);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x66);
	ILI9341_Write_Data(0x40);
	ILI9341_Write_Cmd(0x67);
	ILI9341_Write_Data(0x03);
	ILI9341_Write_Cmd(0x68);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x69);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x6A);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x6B);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x70);
	ILI9341_Write_Data(0x42);
	ILI9341_Write_Cmd(0x71);
	ILI9341_Write_Data(0xE0);
	ILI9341_Write_Cmd(0x72);
	ILI9341_Write_Data(0x40);
	ILI9341_Write_Cmd(0x73);
	ILI9341_Write_Data(0x40);
	ILI9341_Write_Cmd(0x74);
	ILI9341_Write_Data(0x02);
	ILI9341_Write_Cmd(0x75);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x76);
	ILI9341_Write_Data(0x40);
	ILI9341_Write_Cmd(0x77);
	ILI9341_Write_Data(0x03);
	ILI9341_Write_Cmd(0x78);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x79);
	ILI9341_Write_Data(0x00);

	ILI9341_Write_Cmd(0x7A);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x7B);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x80);
	ILI9341_Write_Data(0x48);
	ILI9341_Write_Cmd(0x81);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x82);
	ILI9341_Write_Data(0x05);
	ILI9341_Write_Cmd(0x83);
	ILI9341_Write_Data(0x02);
	ILI9341_Write_Cmd(0x84);
	ILI9341_Write_Data(0xDD);
	ILI9341_Write_Cmd(0x85);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x86);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x87);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x88);
	ILI9341_Write_Data(0x48);
	ILI9341_Write_Cmd(0x89);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x8A);
	ILI9341_Write_Data(0x07);
	ILI9341_Write_Cmd(0x8B);
	ILI9341_Write_Data(0x02);
	ILI9341_Write_Cmd(0x8C);
	ILI9341_Write_Data(0xDF);
	ILI9341_Write_Cmd(0x8D);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x8E);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x8F);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x90);
	ILI9341_Write_Data(0x48);
	ILI9341_Write_Cmd(0x91);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x92);

	ILI9341_Write_Data(0x09);
	ILI9341_Write_Cmd(0x93);
	ILI9341_Write_Data(0x02);
	ILI9341_Write_Cmd(0x94);
	ILI9341_Write_Data(0xE1);
	ILI9341_Write_Cmd(0x95);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x96);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x97);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x98);
	ILI9341_Write_Data(0x48);
	ILI9341_Write_Cmd(0x99);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x9A);
	ILI9341_Write_Data(0x0B);
	ILI9341_Write_Cmd(0x9B);
	ILI9341_Write_Data(0x02);
	ILI9341_Write_Cmd(0x9C);
	ILI9341_Write_Data(0xE3);
	ILI9341_Write_Cmd(0x9D);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x9E);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x9F);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xA0);
	ILI9341_Write_Data(0x48);
	ILI9341_Write_Cmd(0xA1);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xA2);
	ILI9341_Write_Data(0x04);
	ILI9341_Write_Cmd(0xA3);
	ILI9341_Write_Data(0x02);
	ILI9341_Write_Cmd(0xA4);
	ILI9341_Write_Data(0xDC);
	ILI9341_Write_Cmd(0xA5);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xA6);
	ILI9341_Write_Data(0x00);

	ILI9341_Write_Cmd(0xA7);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xA8);
	ILI9341_Write_Data(0x48);
	ILI9341_Write_Cmd(0xA9);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xAA);
	ILI9341_Write_Data(0x06);
	ILI9341_Write_Cmd(0xAB);
	ILI9341_Write_Data(0x02);
	ILI9341_Write_Cmd(0xAC);
	ILI9341_Write_Data(0xDE);
	ILI9341_Write_Cmd(0xAD);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xAE);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xAF);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xB0);
	ILI9341_Write_Data(0x48);
	ILI9341_Write_Cmd(0xB1);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xB2);
	ILI9341_Write_Data(0x08);
	ILI9341_Write_Cmd(0xB3);
	ILI9341_Write_Data(0x02);
	ILI9341_Write_Cmd(0xB4);
	ILI9341_Write_Data(0xE0);
	ILI9341_Write_Cmd(0xB5);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xB6);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xB7);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xB8);
	ILI9341_Write_Data(0x48);
	ILI9341_Write_Cmd(0xB9);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xBA);
	ILI9341_Write_Data(0x0A);
	ILI9341_Write_Cmd(0xBB);

	ILI9341_Write_Data(0x02);
	ILI9341_Write_Cmd(0xBC);
	ILI9341_Write_Data(0xE2);
	ILI9341_Write_Cmd(0xBD);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xBE);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xBF);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xC0);
	ILI9341_Write_Data(0x12);
	ILI9341_Write_Cmd(0xC1);
	ILI9341_Write_Data(0xAA);
	ILI9341_Write_Cmd(0xC2);
	ILI9341_Write_Data(0x65);
	ILI9341_Write_Cmd(0xC3);
	ILI9341_Write_Data(0x74);
	ILI9341_Write_Cmd(0xC4);
	ILI9341_Write_Data(0x47);
	ILI9341_Write_Cmd(0xC5);
	ILI9341_Write_Data(0x56);
	ILI9341_Write_Cmd(0xC6);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xC7);
	ILI9341_Write_Data(0x88);
	ILI9341_Write_Cmd(0xC8);
	ILI9341_Write_Data(0x99);
	ILI9341_Write_Cmd(0xC9);
	ILI9341_Write_Data(0x33);
	ILI9341_Write_Cmd(0xD0);
	ILI9341_Write_Data(0x21);
	ILI9341_Write_Cmd(0xD1);
	ILI9341_Write_Data(0xAA);
	ILI9341_Write_Cmd(0xD2);
	ILI9341_Write_Data(0x65);
	ILI9341_Write_Cmd(0xD3);
	ILI9341_Write_Data(0x74);
	ILI9341_Write_Cmd(0xD4);
	ILI9341_Write_Data(0x47);
	ILI9341_Write_Cmd(0xD5);
	ILI9341_Write_Data(0x56);

	ILI9341_Write_Cmd(0xD6);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xD7);
	ILI9341_Write_Data(0x88);
	ILI9341_Write_Cmd(0xD8);
	ILI9341_Write_Data(0x99);
	ILI9341_Write_Cmd(0xD9);
	ILI9341_Write_Data(0x33);
	ILI9341_Write_Cmd(0xF3);
	ILI9341_Write_Data(0x01);
	ILI9341_Write_Cmd(0xF0);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0xF0);
	ILI9341_Write_Data(0x01);
	ILI9341_Write_Cmd(0xF1);
	ILI9341_Write_Data(0x01);
	ILI9341_Write_Cmd(0xA0);
	ILI9341_Write_Data(0x0B);
	ILI9341_Write_Cmd(0xA3);
	ILI9341_Write_Data(0x2A);
	ILI9341_Write_Cmd(0xA5);
	ILI9341_Write_Data(0xC3);
	HAL_Delay(1);  //delay_ms 1
	ILI9341_Write_Cmd(0xA3);
	ILI9341_Write_Data(0x2B);
	ILI9341_Write_Cmd(0xA5);
	ILI9341_Write_Data(0xC3);
	HAL_Delay(1);  //delay_ms 1
	ILI9341_Write_Cmd(0xA3);
	ILI9341_Write_Data(0x2C);
	ILI9341_Write_Cmd(0xA5);
	ILI9341_Write_Data(0xC3);
	HAL_Delay(1);  //delay_ms 1
	ILI9341_Write_Cmd(0xA3);
	ILI9341_Write_Data(0x2D);
	ILI9341_Write_Cmd(0xA5);
	ILI9341_Write_Data(0xC3);
	HAL_Delay(1);  //delay_ms 1
	ILI9341_Write_Cmd(0xA3);
	ILI9341_Write_Data(0x2E);
	ILI9341_Write_Cmd(0xA5);

	ILI9341_Write_Data(0xC3);
	HAL_Delay(1);  //delay_ms 1
	ILI9341_Write_Cmd(0xA3);
	ILI9341_Write_Data(0x2F);
	ILI9341_Write_Cmd(0xA5);
	ILI9341_Write_Data(0xC3);
	HAL_Delay(1);  //delay_ms 1
	ILI9341_Write_Cmd(0xA3);
	ILI9341_Write_Data(0x30);
	ILI9341_Write_Cmd(0xA5);
	ILI9341_Write_Data(0xC3);
	HAL_Delay(1);  //delay_ms 1
	ILI9341_Write_Cmd(0xA3);
	ILI9341_Write_Data(0x31);
	ILI9341_Write_Cmd(0xA5);
	ILI9341_Write_Data(0xC3);
	HAL_Delay(1);  //delay_ms 1
	ILI9341_Write_Cmd(0xA3);
	ILI9341_Write_Data(0x32);
	ILI9341_Write_Cmd(0xA5);
	ILI9341_Write_Data(0xC3);
	HAL_Delay(1);  //delay_ms 1
	ILI9341_Write_Cmd(0xA3);
	ILI9341_Write_Data(0x33);
	ILI9341_Write_Cmd(0xA5);
	ILI9341_Write_Data(0xC3);
	HAL_Delay(1);  //delay_ms 1
	ILI9341_Write_Cmd(0xA0);
	ILI9341_Write_Data(0x09);
	ILI9341_Write_Cmd(0xF1);
	ILI9341_Write_Data(0x10);
	ILI9341_Write_Cmd(0xF0);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x2A);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Data(0x01);
	ILI9341_Write_Data(0x67);
	ILI9341_Write_Cmd(0x2B);
	ILI9341_Write_Data(0x01);
	ILI9341_Write_Data(0x68);

	ILI9341_Write_Data(0x01);
	ILI9341_Write_Data(0x68);
	ILI9341_Write_Cmd(0x4D);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x4E);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x4F);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x4C);
	ILI9341_Write_Data(0x01);
	HAL_Delay(10);  //delay_ms 10
	ILI9341_Write_Cmd(0x4C);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Cmd(0x2A);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Data(0x01);
	ILI9341_Write_Data(0x67);
	ILI9341_Write_Cmd(0x2B);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Data(0x00);
	ILI9341_Write_Data(0x01);
	ILI9341_Write_Data(0x67);
	ILI9341_Write_Cmd(0x21);
	ILI9341_Write_Cmd(0x11);
	HAL_Delay(120);  //delay_ms 120
	ILI9341_Write_Cmd(0x29);

	ILI9341_Write_Cmd(0x3A);
	ILI9341_Write_Data(0x55);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
